package com.company.problemstatement1.problem1_1;

import java.util.Scanner;

public class EvenNumberDemo {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        int num;

        System.out.println("Enter the Number: ");

        num = scanner.nextInt();

        System.out.println("Even Numbers less than "+num);

        for (int i = 0; i < num; i++){
            if(i % 2 == 0){
                System.out.println(i+ " ");
            }
        }
        System.out.println();
    }
}
