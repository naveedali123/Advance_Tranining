package com.company.problemstatement3.problem3_2;

public interface MedicineInfo {
    void displayLabel();
}

class Tablet implements MedicineInfo {

    public void displayLabel() {
        System.out.println("store in a cool dry place");
    }
}
class Syrup implements MedicineInfo {

    public void displayLabel() {
        System.out.println("Consumption as directed by the physician");
    }
}
class Ointment implements MedicineInfo {

    public void displayLabel() {
        System.out.println("for external use only");
    }
}