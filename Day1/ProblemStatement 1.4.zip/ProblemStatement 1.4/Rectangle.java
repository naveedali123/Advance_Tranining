package com.company.problemstatement1.problem1_4;
import java.util.Scanner;

public class Rectangle {

   private double length;
   private double width;

   public Rectangle(){
       this.length = 1.0;
       this.width = 1.0;
   }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
       if(length > 0.0 && length < 20.0){
           this.length = length;
       }else {
           System.out.println("length should not be greater than 20");
       }
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        if(width > 0.0 && width < 20.0){
            this.width = width;
        }else {
            System.out.println("width should not be greater than 20");
        }
    }

    public void getPerimeter(double length, double width){
       double perimeter = 2*(length*width);

        System.out.println("Perimeter of Rectangle: "+perimeter);
    }

    public void getArea(double length, double width){
        double area = length*width;

        System.out.println("Area of Rectangle: "+area);
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        Rectangle rectangle = new Rectangle();

        System.out.println("Enter Length and Width: ");

        double len = sc.nextDouble();
        double wid = sc.nextDouble();

        rectangle.setLength(len);
        rectangle.setWidth(wid);

        rectangle.getPerimeter(rectangle.getLength(), rectangle.getWidth());
        rectangle.getArea(rectangle.getLength(), rectangle.getWidth());

    }
}
