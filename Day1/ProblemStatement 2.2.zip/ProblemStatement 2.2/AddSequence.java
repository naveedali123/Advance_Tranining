package com.company.problemstatement2.problem2_2;

import java.util.Scanner;

public class AddSequence {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a First two numbers: ");
        int num1 = sc.nextInt();

        int num2 = sc.nextInt();

        System.out.println("Enter number of terms: ");
        int noOfTerms = sc.nextInt();

        int firstTerm = num1, secondTerm = num2;
        System.out.println("Addition Sequence till " + num2 + " terms:");

        for (int i = num1; i<=noOfTerms+2; i++){
            System.out.print(firstTerm + " ");

            int nextTerm = firstTerm + secondTerm;
            firstTerm = secondTerm;
            secondTerm = nextTerm;

            num1++;
        }
    }
}
