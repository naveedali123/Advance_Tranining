package com.company.problemstatement1.problem1_2;

public class Rectangle {
    public double length;
    public double breadth;
    public double area;


    //default constructor
    public Rectangle() {
        this.length = 0;
        this.breadth = 0;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getBreadth() {
        return breadth;
    }

    public void setBreadth(double breadth) {
        this.breadth = breadth;
    }

    //find area of rectangle
    public void printArea() {
        area = this.length * this.breadth;
        System.out.println("Area of Rectangle : " + area);
    }

    // display all data of rectangle
    public void printData() {
        System.out.println("Length of Rectangle is : " + this.length);
        System.out.println("Breadth of Rectangle is : " + this.breadth);

    }
}
