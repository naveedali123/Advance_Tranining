package com.company.problemstatement1.problem1_2;

import java.util.*;

public class TestRectangle {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        //First Rectangle Object
        Rectangle r1 = new Rectangle();
        System.out.println("Enter length and breadth for rectangle 1: ");
        double len1 = sc.nextDouble();
        double br1 = sc.nextDouble();

        r1.setLength(len1);
        r1.setBreadth(br1);

        r1.printArea();
        r1.printData();
        System.out.println();

        //Second Rectangle Object
        Rectangle r2 = new Rectangle();
        System.out.println("Enter length and breadth for rectangle 2: ");
        double len2 = sc.nextDouble();
        double br2 = sc.nextDouble();

        r2.setLength(len2);
        r2.setBreadth(br2);

        r2.printArea();
        r2.printData();
        System.out.println();

        //Third Rectangle Object
        Rectangle r3 = new Rectangle();
        System.out.println("Enter length and breadth for rectangle 3: ");
        double len3 = sc.nextDouble();
        double br3 = sc.nextDouble();

        r3.setLength(len3);
        r3.setBreadth(br3);

        r3.printArea();
        r3.printData();
        System.out.println();

        //Fourth Rectangle Object
        Rectangle r4 = new Rectangle();
        System.out.println("Enter length and breadth for rectangle 4: ");
        double len4 = sc.nextDouble();
        double br4 = sc.nextDouble();

        r4.setLength(len4);
        r4.setBreadth(br4);

        r4.printArea();
        r4.printData();
        System.out.println();

        //Fifth Rectangle Object
        Rectangle r5 = new Rectangle();
        System.out.println("Enter length and breadth for rectangle 5: ");
        double len5 = sc.nextDouble();
        double br5 = sc.nextDouble();

        r5.setLength(len5);
        r5.setBreadth(br5);

        r5.printArea();
        r5.printData();

    }
}
