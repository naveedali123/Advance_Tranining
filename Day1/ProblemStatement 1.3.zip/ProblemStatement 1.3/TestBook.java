package com.company.problemstatement1.problem1_3;

import java.util.*;

public class TestBook {

    public static void createBook(){

        Book[] book=new Book[2];

        book[0] = new Book("Java Programing", 350.50);
        book[1] = new Book("Let Us C", 200.00);

        showBooks(book);
    }

    public static void showBooks(Book[] book) {
        for(int i = 0; i<book.length; i++) {
            System.out.println("Title: "+book[i].getBook_title()+" \t "+"Price: "+book[i].getBook_price());
        }
    }

    public static void main(String[] args){

        createBook();

    }
}
