package com.company.problemstatement2.problem2_3;

import java.util.Arrays;

public class IntegerArray {
    public static void main(String[] args) {
        int[] arr = { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };

        int[] copiedArray = new int[20];

        int sum = 0;

        for (int i = 0; i < 15; i++) {
            sum = sum + arr[i];
        }

        arr[15] = sum;

        double average = sum / arr.length;

        arr[16] = (int)average;

        int min = arr[0];
        for(int i=1; i<arr.length - 1; i++) {
            if(min>arr[i])
                min=arr[i];
        }

        arr[17] = min;

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
