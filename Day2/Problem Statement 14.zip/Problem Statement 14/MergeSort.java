package com.company.problemstatement14;

import java.util.*;

public class MergeSort {
    public static void sortedMerge(int a[], int b[], int res[], int n, int m) {

        // Concatenate two arrays
        int i = 0, j = 0, k = 0;

        while (i < n) {
            res[k] = a[i];
            i++;
            k++;
        }

        while (j < m) {
            res[k] = b[j];
            j++;
            k++;
        }

        // sorting the res array
        Arrays.sort(res);
    }

    /* Driver program to test above function */
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter length of first array: ");
        int len1 = scanner.nextInt();

        System.out.println("Enter length of second array: ");
        int len2 = scanner.nextInt();

        int[] arr1 = new int[len1];
        int[] arr2 = new int[len2];

        System.out.println("Enter first array");
        for (int i=0; i<arr1.length; i++){
            arr1[i] = scanner.nextInt();
        }

        System.out.println("Enter second array");
        for (int i=0; i<arr2.length; i++){
            arr2[i] = scanner.nextInt();
        }

        // Final merge list
        int res[]=new int[len1 + len2];
        sortedMerge(arr1, arr2, res, len1, len2);

        System.out.print("Sorted merged list :");
        for (int i = 0; i < len1 + len2; i++)
            System.out.print(" " + res[i]);
    }
}
