package com.company.problemstatement16;

import java.util.Scanner;

public class ClimbingStairs {

    static int fib(int n) {
        if (n <= 1)
            return n;
        return fib(n - 1) + fib(n - 2);
    }

    // Returns number of ways to reach s'th stair
    static int countWays(int s) {
        return fib(s + 1);
    }

    /* Driver program to test above function */
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Steps: ");
        int step = scanner.nextInt();

        if(step>=1 && step<=45){
            System.out.println("Number of ways = " + countWays(step));
        }else {
            System.out.println("Enter values between 1 to 45");
        }
    }
}
